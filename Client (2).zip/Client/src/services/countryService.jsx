import axios from 'axios';

const API_URL = 'http://localhost:5000/api/countries';

const getAllCountries = async () => {
  const response = await axios.get(API_URL);
  return response.data;
};

const getCountryDetails = async (countryId) => {
  const response = await axios.get(`${API_URL}/${countryId}`);
  return response.data;
};

const countryService = {
  getAllCountries,
  getCountryDetails,
};

export default countryService;
