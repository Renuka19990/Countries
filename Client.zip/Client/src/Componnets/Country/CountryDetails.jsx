import React, { useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom';
import { CountryContext } from '../../context/CountryContext';
import countryService from '../../services/countryService';

const CountryDetails = () => {
    const { currencyCode } = useParams();
    const { countries, setCountries } = useContext(CountryContext);

    useEffect(() => {
        const fetchCountryDetails = async () => {
            const data = await countryService.getCountryByCurrency(currencyCode);
            setCountries(data);
        };
        fetchCountryDetails();
    }, [currencyCode, setCountries]);

    return (
        <div>
            {countries.map((country) => (
                <CountryCard key={country.cca2} country={country} />
            ))}
        </div>
    );
};

export default CountryDetails;
