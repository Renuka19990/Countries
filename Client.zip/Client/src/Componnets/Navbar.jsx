import React from 'react';
import { Box, Flex, Button, Avatar, Menu, MenuButton, MenuList, MenuItem, MenuDivider, useColorMode, Center } from '@chakra-ui/react'; // Adjust imports as needed for Chakra UI components
import { MoonIcon, SunIcon } from '@chakra-ui/icons';
import { Link } from 'react-router-dom'; // Import Link for routing

export default function Nav() {
  const { colorMode, toggleColorMode } = useColorMode();

  return (
    <Box bg={colorMode === 'light' ? 'gray.100' : 'gray.900'} px={4}>
      <Flex h={16} alignItems="center" justifyContent="space-between">
        <Box>Logo</Box>

        <Flex alignItems="center">
          <Button onClick={toggleColorMode}>
            {colorMode === 'light' ? <MoonIcon /> : <SunIcon />}
          </Button>

          <Menu>
            <MenuButton
              as={Button}
              rounded="full"
              variant="link"
              cursor="pointer"
              minW={0}
            >
              <Avatar
                size="sm"
                src="https://avatars.dicebear.com/api/male/username.svg"
                alt="User Avatar"
              />
            </MenuButton>
            <MenuList alignItems="center">
              <br />
              <Center>
                <Avatar
                  size="2xl"
                  src="https://avatars.dicebear.com/api/male/username.svg"
                  alt="User Avatar"
                />
              </Center>
              <br />
              <Center>
                <p>Username</p>
              </Center>
              <br />
              <MenuDivider />
              <MenuItem>
                <Link to="/servers">Your Servers</Link>
              </MenuItem>
              <MenuItem>
                <Link to="/settings">Account Settings</Link>
              </MenuItem>
              <MenuItem>
                <Link to="/logout">Logout</Link>
              </MenuItem>
            </MenuList>
          </Menu>
        </Flex>
      </Flex>
    </Box>
  );
}
