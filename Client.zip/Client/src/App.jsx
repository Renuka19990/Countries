
import './App.css'
import Nav from './Componnets/Navbar'
import Allrouter from './Routes/Allrouter'

function App() {


  return (
    <>
     <Nav/>
     <Allrouter/>
    </>
  )
}

export default App
