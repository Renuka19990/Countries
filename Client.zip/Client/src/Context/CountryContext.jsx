import React, { createContext, useState } from 'react';

const CountryContext = createContext();

const CountryProvider = ({ children }) => {
    const [countries, setCountries] = useState([]);

    return (
        <CountryContext.Provider value={{ countries, setCountries }}>
            {children}
        </CountryContext.Provider>
    );
};

export { CountryProvider, CountryContext };
